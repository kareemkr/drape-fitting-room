"""Fetch publicly released, hash-pinned model files into this folder."""
from pathlib import Path
from hashlib import sha256
from urllib.request import urlopen
from shutil import copyfileobj
BASE=Path(__file__).resolve().parent
release='https://github.com/KiseKloset/DM-VTON/releases/download/1.0.0/'
assets=[
('gen.pt',release+'dmvton_pf_gen.pt','3147a3731e5fc18c473f563a4d896a5ddf620f0a7f293b8fbda3069a76e8e6f7'),
('warp.pt',release+'dmvton_pf_warp.pt','0e2fb5220f0e6829a17de8894c56b09463e08f279aa4ac410bf808bc6287b74e'),
('pose_landmarker_lite.task','https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task','59929e1d1ee95287735ddd833b19cf4ac46d29bc7afddbbf6753c459690d574a'),
('selfie_multiclass_256x256.tflite','https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_multiclass_256x256/float32/1/selfie_multiclass_256x256.tflite','c6748b1253a99067ef71f7e26ca71096cd449baefa8f101900ea23016507e0e0')]
def digest(p):
 with p.open('rb') as f:
    h=sha256()
    while chunk:=f.read(1024*1024):h.update(chunk)
    return h.hexdigest()
if __name__=='__main__':
 for name,url,expected in assets:
    dest=BASE/name
    if dest.exists() and digest(dest)==expected:continue
    pending=dest.with_suffix('.partial')
    try:
        with urlopen(url,timeout=120) as src, pending.open('wb') as out:copyfileobj(src,out,1024*1024)
        if digest(pending)!=expected:raise ValueError('Checksum mismatch for '+name)
        pending.replace(dest)
        print('Verified',name)
    finally:
        pending.unlink(missing_ok=True)
