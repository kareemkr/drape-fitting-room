"""Use the actual pretrained research model on a local portrait and top."""
import argparse,shutil,tempfile
from pathlib import Path
from PIL import Image, ImageOps
from benchmark import TryOn,base,make_detector,make_parts,run_case
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--person',type=Path,required=True)
    p.add_argument('--garment',type=Path,required=True)
    p.add_argument('--edge',type=Path,help='Optional garment mask; white is fabric.')
    p.add_argument('--out',type=Path,required=True,help='Output JPEG path')
    p.add_argument('--pose-model',type=Path,default=base/'pose_landmarker_lite.task')
    p.add_argument('--parts-model',type=Path,default=base/'selfie_multiclass_256x256.tflite')
    a=p.parse_args()
    if a.out.suffix.lower() not in {'.jpg','.jpeg'}:p.error('Choose a JPEG output filename.')
    if a.out.exists():p.error('Choose a new output filename.')
    if not a.person.is_file() or not a.garment.is_file():p.error('Check the input paths.')
    with tempfile.TemporaryDirectory() as name:
        work=Path(name)
        for sub in ('raw','metadata','outputs'):(work/sub).mkdir()
        row={'id':'try-on','person':str(a.person.resolve()),'garment':str(a.garment.resolve()),'edge':str(a.edge.resolve()) if a.edge else None}
        model=TryOn()
        with make_detector(a.pose_model) as detector,make_parts(a.parts_model) as parts:
            result=run_case(row,work,work,model,detector,parts)
        a.out.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(work/'outputs/try-on.jpg',a.out)
        print('Saved',a.out,'| learned prediction',result['prediction_dimensions'])
if __name__=='__main__':main()
