"""CPU inference for the official noncommercial DM-VTON student checkpoints."""
from pathlib import Path
import sys
import types
import time
import numpy as np
from PIL import Image, ImageOps
import torch
import torch.nn.functional as F
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'DM-VTON-main'))
def correlation(tenFirst, tenSecond, intStride):
    """Exact mean dot product across channels in the original 7x7 displacement order."""
    if intStride != 1: raise ValueError('This model always uses unit stride')
    height,width=tenFirst.shape[-2:]
    padded=F.pad(tenSecond,(3,3,3,3))
    return torch.stack([
        (tenFirst * padded[...,dy:dy+height, dx:dx+width]).mean(1)
        for dy in range(7) for dx in range(7)
    ],1)
cpu_correlation=types.ModuleType('models.common.correlation')
cpu_correlation.FunctionCorrelation=correlation
sys.modules[cpu_correlation.__name__]=cpu_correlation
from models.generators.mobile_unet import MobileNetV2_unet
from models.warp_modules.mobile_afwm import MobileAFWM

def apply_weights(model,filename):
    with torch.serialization.safe_globals([(np._core.multiarray.scalar, 'numpy.core.multiarray.scalar'),np.dtype, type(np.dtype('float64')),type(np.dtype('float32'))]):
        data=torch.load(root/filename,weights_only=True,map_location='cpu')
    weights=data.get('model',data)
    required=model.state_dict().keys()
    model.load_state_dict({k:weights[k] for k in required},strict=True)
    model.eval()
    return model
def rgb_tensor(im):
    rgb=np.array(im.convert('RGB'),np.float32)/127.5-1
    return torch.from_numpy(rgb).permute(2,0,1).unsqueeze(0)
def decode_image(t):
    a=t[0].clamp(-1,1).permute(1,2,0).mul(127.5).add(127.5).round().to(torch.uint8).numpy()
    return Image.fromarray(a)
class TryOn:
    def __init__(self, threads=3):
        torch.set_num_threads(threads)
        self.warp=apply_weights(MobileAFWM(3,True),'warp.pt')
        self.gen=apply_weights(MobileNetV2_unet(7,4),'gen.pt')
    @torch.inference_mode()
    def run(self,person,garment,mask=None,person_box=None,product_padded=False):
        start=time.perf_counter()
        dims=(192,256)
        original=(person if isinstance(person,Image.Image) else ImageOps.exif_transpose(Image.open(person))).convert('RGB')
        person_img=original.crop(person_box) if person_box else original
        person_img=person_img.resize(dims,Image.Resampling.LANCZOS)
        cloth_im=ImageOps.exif_transpose(Image.open(garment)).convert('RGBA')
        if mask:
            alpha=Image.open(mask).convert('L').resize(cloth_im.size,Image.Resampling.BILINEAR)
        elif cloth_im.getchannel('A').getextrema()[0]<100:
            alpha=cloth_im.getchannel('A')
        else:
            # Extract flat plain backgrounds by edge-connected color distance.
            from scipy import ndimage
            rgb=np.asarray(cloth_im.convert('RGB')).astype(np.int16)
            edges=np.concatenate([rgb[0],rgb[-1],rgb[:,0],rgb[:,-1]])
            bg=np.median(edges[::max(1,len(edges)//600)],axis=0)
            d=np.max(np.abs(rgb-bg),axis=2)
            candidate=d<max(14,min(45,np.percentile(np.max(abs(edges-bg),axis=1),90)+9))
            seed=np.zeros_like(candidate)
            seed[0,:]=candidate[0,:];seed[-1,:]=candidate[-1,:];seed[:,0]=candidate[:,0];seed[:,-1]=candidate[:,-1]
            keep=~ndimage.binary_propagation(seed,mask=candidate)
            alpha=Image.fromarray((keep*255).astype('uint8'))
        if product_padded:
            # Catalogue images with preserved product-as-shot use same framing for both channels.
            cloth=cloth_im.convert('RGB').resize(dims,Image.Resampling.LANCZOS)
            edge=alpha.resize(dims, Image.Resampling.BILINEAR)
        else:
            bbox=alpha.point(lambda i:255 if i>80 else 0).getbbox() or (0,0,*cloth_im.size)
            clip=cloth_im.convert('RGB').crop(bbox); edge_clip=alpha.crop(bbox)
            inner=(182,240)
            ratio=min(inner[0]/clip.width,inner[1]/clip.height)
            size=tuple(max(1,round(s*ratio)) for s in clip.size)
            offset=((dims[0]-size[0])//2,(dims[1]-size[1])//2)
            cloth=Image.new('RGB',dims,'white');cloth.paste(clip.resize(size,Image.Resampling.LANCZOS),offset)
            edge=Image.new('L',dims);edge.paste(edge_clip.resize(size,Image.Resampling.BILINEAR),offset)
        p=rgb_tensor(person_img)
        c=rgb_tensor(cloth)
        e=torch.from_numpy((np.array(edge)>127).astype('float32'))[None,None]
        c=c*e
        warped, flow=self.warp(p,c,phase='test')
        warped_edge=F.grid_sample(e,flow.permute(0,2,3,1),mode='bilinear',padding_mode='zeros',align_corners=True)
        g=self.gen(torch.cat([p,warped,warped_edge],1))
        synthesis, mask=g.split([3,1],dim=1)
        wt=torch.sigmoid(mask)*warped_edge
        rendered=warped*wt+torch.tanh(synthesis)*(1-wt)
        return decode_image(rendered),person_img,cloth,time.perf_counter()-start
