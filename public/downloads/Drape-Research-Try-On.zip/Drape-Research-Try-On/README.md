# Drape research try-on runner

Run the same neural model used for the 100-case upper-body benchmark on a local computer. The original DM-VTON student learns dense garment flow and image synthesis. The inference code computes its 49-channel correlation with PyTorch CPU operations, uses the published model weights, and renders at its native 192 × 256 resolution. The final image uses the source photo dimensions. Clothes are estimated from a front-facing flat product image, with either a transparent background, a plain background, or an optional binary garment mask.

## Setup

Tested with Linux x86-64 and Python 3.12. In a new virtual environment, run:

```sh
python -m pip install --index-url https://download.pytorch.org/whl/cpu "torch==2.7.1"
python -m pip install -r requirements.txt
python fetch_models.py
```

The last command downloads the two released student checkpoints and two vision models and verifies their SHA-256 hashes. Weight downloads happen once. Afterward, inference runs locally.

## One outfit

```sh
python try_photo.py --person portrait.jpg --garment top.png --out new-look.jpg
```

For a garment photographed on a complex background, add `--edge garment-mask.png`. Use white for garment and black for background. For front views, include the head, both shoulders and waist. Products other than tops, oblique views, closely crossed arms and unusual draping fall outside this small research model's reliable range. Source cropping, low native resolution and inaccurate sleeves can affect the result. The preview does not determine a physical clothing size.

## Repeat a benchmark

```sh
python benchmark.py --manifest path/to/pairs.json --output run
```

Each manifest item has an `id`, `person`, `garment`, `edge`, `cohort`, `garment_type` and `difficulty`. Image paths are relative to the manifest. The runner ignores the independent `reference` path. It saves raw neural predictions, full-frame results and per-case timings, crop coordinates, segmentation flags and SHA-256. Existing case metadata allows resuming a stopped run.

The full-frame processor uses MediaPipe landmarks and person segmentation to prepare the upper-body crop. A separate selfie segmentation model protects visible face and hair. The two networks warp the product and synthesize the clothed person. The processor then restores the original scene and detail outside the editable area. Fabric flow and the garment appearance inside that area come from the student model.

## Credits and terms

DM-VTON was created by Khoi-Nguyen Nguyen-Ngoc, Thanh-Tung Phan-Nguyen, Khanh-Duy Le, Tam V. Nguyen, Minh-Triet Tran and Trung-Nghia Le. This bundle includes the required unchanged model architecture modules from commit `5dcd04ee3f5b1fb392df1184c887c1a7e910c72e`. Inference uses the authors' release 1.0.0. Their code is released for noncommercial academic use under CC BY-NC-SA 4.0. The CPU inference adaptation and benchmark runner are provided under the same terms. The full upstream license is included in `DM-VTON-main/LICENSE`.

Source, paper, and published checkpoints:

- https://github.com/KiseKloset/DM-VTON
- https://arxiv.org/abs/2308.13798
- https://github.com/KiseKloset/DM-VTON/releases/tag/1.0.0

Pose Landmarker Lite and Selfie Multiclass are Google MediaPipe models. Source URLs and their verified digests are in `fetch_models.py`. The CURVTON research subset, when supplied separately, has its own dataset terms.
