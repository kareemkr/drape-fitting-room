"""Run the pretrained DM-VTON student on independent person/garment inputs.

The held-out reference is never read by this module. The learned flow and generator
produce native 192x256 images. Foreground, vertical edit limits, and hands let the
unaltered high-resolution scene remain outside the try-on area.
"""
import argparse, hashlib, json, sys, time, types, warnings
from pathlib import Path
from PIL import Image,ImageOps
import numpy as np
from scipy import ndimage
try:
    import cv2
except ImportError:
    # The landmark task uses the native runtime. Its optional drawing helper imports cv2.
    sys.modules['cv2']=types.ModuleType('cv2')
import mediapipe as mp
from mediapipe.tasks.python import BaseOptions, vision
from cpu_model import TryOn
base=Path(__file__).resolve().parent
def image_u8(a):
    return Image.fromarray(np.rint(255*np.clip(np.squeeze(a),0,1)).astype(np.uint8))
def make_detector(task):
    options=vision.PoseLandmarkerOptions(base_options=BaseOptions(model_asset_path=str(task)),num_poses=1,min_pose_detection_confidence=.30,min_pose_presence_confidence=.32,output_segmentation_masks=True)
    return vision.PoseLandmarker.create_from_options(options)
def detect(detector,src):
    im=src.copy();im.thumbnail((512,512),Image.Resampling.LANCZOS)
    safe_width=max(16,round(im.width/16)*16)
    im=im.resize((safe_width,im.height),Image.Resampling.BILINEAR)
    result=detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB,data=np.array(im.convert('RGB'))))
    if not result.pose_landmarks or not result.segmentation_masks: return None,None
    kp=np.array([[p.x*src.width,p.y*src.height, min(p.visibility,p.presence)] for p in result.pose_landmarks[0]])
    mask=np.asarray(image_u8(result.segmentation_masks[0].numpy_view()).resize(src.size,Image.Resampling.BILINEAR)).astype('float32')/255
    return kp,mask
def portrait(src,landmarks):
    w,h=src.size
    if landmarks is None:
        ch=min(h,w*1.05);cx=w*.5;top=0;bottom=ch; left=cx-(bottom-top)*.375
        return (int(left),0,int(left+(bottom-top)*.75),round(bottom))
    points=landmarks
    shoulders=points[[11,12],:2].mean(axis=0);hips=points[[23,24],:2].mean(axis=0)
    sy,hy=shoulders[1],hips[1]
    t=max(h*.14,hy-sy)
    # The student was trained on straight-on waist-up portraits. Retain upper thighs.
    top=max(0,sy-t*.79);bottom=min(h,hy+t*.57)
    cw=(bottom-top)*.75
    cx=(shoulders[0]*.6+hips[0]*.4)
    left=min(max(0,cx-cw/2),max(0,w-cw));return tuple(map(round,(left,top,left+cw,bottom)))
def make_parts(task):
    options=vision.ImageSegmenterOptions(base_options=BaseOptions(model_asset_path=str(task)),output_category_mask=False,output_confidence_masks=True)
    return vision.ImageSegmenter.create_from_options(options)
def source_parts(segmenter,patch):
    im=patch.copy();im.thumbnail((400,400),Image.Resampling.LANCZOS)
    im=im.resize((max(16,round(im.width/16)*16),im.height),Image.Resampling.BILINEAR)
    result=segmenter.segment(mp.Image(image_format=mp.ImageFormat.SRGB,data=np.array(im.convert('RGB'))))
    masks=result.confidence_masks
    parts=[]
    for ids in [(1,3),(2,)]:
        prob=sum(np.squeeze(masks[i].numpy_view()).astype('float32') for i in ids)
        parts.append(np.asarray(image_u8(prob).resize(patch.size,Image.Resampling.BILINEAR)).astype('float32')/255)
    return parts
def edit_mask(points,box,shape,identity,skin):
    H,W=shape
    y,x=np.mgrid[:H,:W];top,left=box[1],box[0]
    if points is None:
        return np.minimum(np.clip((y/H-.14)/.06,0,1),np.clip((.91-y/H)/.08,0,1))
    sy=points[[11,12],1].mean(); hy=points[[23,24],1].mean()
    torso=max(1,hy-sy)
    nose=points[0,1]
    y=y+top;x=x+left
    # Preserve identified face and hair rather than drawing a straight boundary
    # through both shoulders, especially when the neck leans toward the camera.
    head_keep=np.clip((identity-.16)/.61,0,1)
    head_keep=ndimage.gaussian_filter(head_keep,max(.5,W/650))
    upper=nose - .40*torso
    mask=np.clip((y-upper)/max(3,torso*.12),0,1)*(1-head_keep)
    mask*=np.clip((hy+torso*.52-y)/max(3,torso*.13),0,1)
    for ids in [[15,17,19],[16,18,20]]:
        wrist, pink, index=points[ids,:]
        if min(wrist[2], max(pink[2],index[2]))>.40:
            hand=(pink[:2]+index[:2])*.5
            vector=hand-wrist[:2];length=np.linalg.norm(vector)
            if length>2:
                dx=(x-wrist[0]);dy=(y-wrist[1])
                along=(dx*vector[0]+dy*vector[1])/length
                perp=np.abs(dx*vector[1]-dy*vector[0])/length
                protect=(np.clip((along-1)/max(2,torso*.025),0,1)*np.clip((length*1.8-along)/max(2,torso*.03),0,1)*np.clip((max(torso*.085,length*.65)-perp)/max(2,torso*.03),0,1))
                mask*=1-protect*np.clip((skin-.12)/.63,0,1)
    return mask
def save_image(im,target):
    tmp=target.with_suffix('.part');im.save(tmp,format='JPEG' if target.suffix=='.jpg' else 'PNG',**({'quality':95,'subsampling':0} if target.suffix=='.jpg' else {}));tmp.replace(target)
def run_case(item,images,output,net,detector,parts):
    cid=item['id'];start=time.perf_counter()
    original=ImageOps.exif_transpose(Image.open(images/item['person'])).convert('RGB')
    points,foreground=detect(detector,original);box=portrait(original,points)
    source=original
    if foreground is not None:
        source=Image.composite(original,Image.new('RGB',original.size,(247,247,247)),image_u8(foreground))
    # Input API also accepts a PIL image, allowing foreground normalization in memory.
    result,_,_,model_seconds=net.run(source,images/item['garment'],images/item['edge'] if item.get('edge') else None,person_box=box)
    native_path=output/'raw'/f'{cid}.png';save_image(result,native_path)
    patch=original.crop(box);w,h=patch.size
    _,generated_foreground=detect(detector,result)
    rgb=np.asarray(result.resize((w,h), Image.Resampling.LANCZOS)).astype('float32')
    scene=np.asarray(patch).astype('float32')
    identity,skin=source_parts(parts,patch)
    allowed=edit_mask(points,box,(h,w),identity,skin)
    if foreground is not None:
        input_fg=foreground[box[1]:box[3],box[0]:box[2]]
        if generated_foreground is None:
            yg,xg=np.mgrid[:h,:w]
            # Conservative fallback if landmarks on the synthesis could not be read.
            output_fg=input_fg
        else:
            output_fg=np.asarray(image_u8(generated_foreground).resize((w,h),Image.Resampling.BILINEAR)).astype('float32')/255
        output_fg=ndimage.gaussian_filter(np.clip((output_fg-.12)/.75,0,1),max(.6,w/460))
        # For areas vacated by a bulky original garment, sample nearest true backdrop.
        region=input_fg>.05
        if np.any(~region):
            nearest=ndimage.distance_transform_edt(region,return_distances=False,return_indices=True)
            bg=scene[tuple(nearest)]
            synth=rgb*output_fg[:,:,None]+bg*(1-output_fg[:,:,None])
            change=np.maximum(output_fg,input_fg)*allowed
        else:
            synth=rgb;change=output_fg*allowed
    else:
        synth=rgb;change=allowed
    patch=Image.fromarray(np.rint(scene*(1-change[:,:,None])+synth*change[:,:,None]).clip(0,255).astype('uint8'))
    frame=original.copy();frame.paste(patch,(box[0],box[1]))
    rendered=output/'outputs'/f'{cid}.jpg';save_image(frame,rendered)
    meta={'id':cid,'cohort':item.get('cohort'),'garment_type':item.get('garment_type'),'difficulty':item.get('difficulty'),'crop_xyxy':box,'original_dimensions':original.size,'prediction_dimensions':result.size,'output_dimensions':frame.size,'model':'KiseKloset/DM-VTON student 1.0.0','model_seconds':round(model_seconds,4),'total_seconds':round(time.perf_counter()-start,4),'source_pose':points is not None,'generated_pose':generated_foreground is not None,'sha256':hashlib.sha256(rendered.read_bytes()).hexdigest(),'raw_sha256':hashlib.sha256(native_path.read_bytes()).hexdigest(),'held_out_reference_used':False,'render_revision':'semantic-face-hair-v2'}
    if points is not None:
        meta['shoulders_hips_normalized']=[[round(float(points[i,0])/original.width,4),round(float(points[i,1])/original.height,4)] for i in [11,12,23,24]]
    dest=output/'metadata'/f'{cid}.json';dest.write_text(json.dumps(meta,indent=1)+'\n')
    print(cid,meta['model_seconds'],meta['total_seconds'],flush=True);return meta
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,default=base.parent/'cases/pairs.json');p.add_argument('--output',type=Path,default=base);p.add_argument('--task',type=Path,default=(base/'pose_landmarker_lite.task' if (base/'pose_landmarker_lite.task').is_file() else base.parent.parent/'drape-studio/public/pose-assets/pose_landmarker_lite.task'));p.add_argument('--parts',type=Path,default=base/'selfie_multiclass_256x256.tflite');p.add_argument('--max',type=int,default=100);p.add_argument('--wait',type=int,default=600);a=p.parse_args()
    for folder in ['raw','outputs','metadata']:(a.output/folder).mkdir(exist_ok=True,parents=True)
    pending=[item for item in json.loads(a.manifest.read_text())[:a.max] if not (a.output/'metadata'/f"{item['id']}.json").is_file()]
    net=TryOn();end=time.monotonic()+a.wait
    with make_detector(a.task) as detector, make_parts(a.parts) as parts:
        while pending:
            if time.monotonic()>=end:raise TimeoutError(f'{len(pending)} missing benchmark inputs')
            progress=False
            for item in list(pending):
                if all((a.manifest.parent/item[k]).is_file() for k in ('person','garment','edge')):
                    run_case(item,a.manifest.parent,a.output,net,detector,parts);pending.remove(item);progress=True
            if not progress:time.sleep(1)
