Drape | 100 on-device size comparisons

Open the Men and Women folders to see 50 cases each. Each JPEG shows the same person and product in three columns: reference, one size up, and two sizes up. Compare a garment across one row to see the effects on width and length. The camera and pose stay fixed.

All 100 people and product images are synthetic studio examples from Drape’s original fit-test gallery. Inputs/ contains the exact original person and flat product image for each case. Each person’s 33 normalized landmarks came from MediaPipe Pose Landmarker Lite run on that specific photograph. poses.json retains those predictions. The renderer uses detected shoulders and hips when available, and shoulder-based waist estimates when hips are cropped or unreliable. cases.csv identifies which alignment each example used.

The photo renderer runs locally. These examples use Drape’s estimated garment grades with no retailer chart or wearer measurements. They illustrate a change relative to the product photo; they cannot establish a shopper’s physical size. Short cuts and open garments can leave the wearer’s original clothing visible.

coverage.json records the number of pixels changed relative to the original at each of the three steps. A pixel counts when any RGB channel differs by at least 10 out of 255. Counts come from the uncompressed 320-pixel-wide rendered images. Each case increased at both size changes. This is a rendering check, not a fit-accuracy score.
