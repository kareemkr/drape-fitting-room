"""Drape single-worker image inference service for FASHN VTON v1.5."""
import argparse
import asyncio
import base64
import binascii
import hmac
import io
import json
import logging
import os
import secrets
import time
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from PIL import Image, ImageOps, UnidentifiedImageError

ROOT = Path(__file__).resolve().parent
CATEGORIES = {"top": "tops", "bottom": "bottoms", "dress": "one-pieces"}
FORMATS = {"image/jpeg": "JPEG", "image/png": "PNG", "image/webp": "WEBP"}
MAX_BODY = 10_700_000
MAX_IMAGE_TEXT = 5_300_000
MAX_JOBS = 3
MAX_RECORDS = 20
RETENTION = 900
LOOPBACK = {"127.0.0.1", "::1", "localhost"}
log = logging.getLogger("drape")


def image_from_data(value):
    if not isinstance(value, str) or len(value) > MAX_IMAGE_TEXT or "," not in value:
        raise ValueError("Each image must be a data URL under 5.3 MB encoded.")
    label, data = value.split(",", 1)
    mime = next((mime for mime in FORMATS if label == "data:" + mime + ";base64"), None)
    if mime is None:
        raise ValueError("Use a JPEG, PNG or WebP image.")
    try:
        raw = base64.b64decode(data, validate=True)
        with Image.open(io.BytesIO(raw)) as source:
            if source.format != FORMATS[mime] or min(source.size) < 32 or source.width * source.height > 20_000_000:
                raise ValueError("Use an image with a matching file type, at least 32 pixels on both sides, and under 20 megapixels.")
            source = ImageOps.exif_transpose(source)
            source.thumbnail((1536, 1536), Image.Resampling.LANCZOS)
            rgba = source.convert("RGBA")
            flat = Image.new("RGB", rgba.size, "white")
            flat.paste(rgba, mask=rgba.getchannel("A"))
            return flat
    except (UnidentifiedImageError, OSError, binascii.Error, Image.DecompressionBombError) as exc:
        raise ValueError("The image could not be decoded.") from exc


def request_images(payload):
    if not isinstance(payload, dict):
        raise ValueError("Expected a JSON object.")
    category = payload.get("category")
    photo_type = payload.get("garmentPhotoType", "flat-lay")
    if category not in CATEGORIES or photo_type not in ("model", "flat-lay"):
        raise ValueError("Choose a supported garment category and photo type.")
    return image_from_data(payload.get("person")), image_from_data(payload.get("garment")), CATEGORIES[category], photo_type


def model_renderer(weights, device, steps):
    import torch
    from fashn_vton import TryOnPipeline
    from fashn_human_parser import FashnHumanParser
    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but PyTorch cannot use a GPU. Install the appropriate CUDA PyTorch wheel, or launch with --device cpu.")
    class PinnedPipeline(TryOnPipeline):
        def _setup_hp_model(self):
            self.hp_model = FashnHumanParser(model_id=str(weights.resolve() / "parser"), device=device)

    model = PinnedPipeline(weights_dir=str(weights), device=device)

    def render(person, garment, category, garment_photo_type):
        result = model(person_image=person, garment_image=garment, category=category,
                       garment_photo_type=garment_photo_type, num_timesteps=steps, num_samples=1,
                       seed=42, guidance_scale=1.5, segmentation_free=True)
        image = result.images[0].convert("RGB")
        data = io.BytesIO()
        image.save(data, format="JPEG", quality=94, optimize=True)
        return "data:image/jpeg;base64," + base64.b64encode(data.getvalue()).decode("ascii")
    return render


def create_app(renderer, token, local):
    if token and len(token) < 32:
        raise ValueError("DRAPE_RENDER_TOKEN must contain at least 32 characters.")
    if not local and not token:
        raise ValueError("Set DRAPE_RENDER_TOKEN before listening beyond loopback.")
    queue = asyncio.Queue(maxsize=MAX_JOBS)
    records = {}

    async def process():
        while True:
            job_id, args = await queue.get()
            rec = records[job_id]
            rec["status"] = "processing"
            try:
                output = await asyncio.to_thread(renderer, *args)
                rec.update(status="completed", output=[output])
            except Exception as exc:
                log.exception("Inference failed (%s)", type(exc).__name__)
                rec.update(status="failed", error={"name": "InferenceError", "message": "The local model could not render this pair. Check the service log and GPU memory."})
            finally:
                rec["_done"] = time.monotonic()
                args = None
                output = None
                rec = None
                queue.task_done()

    def expire():
        cutoff = time.monotonic() - RETENTION
        for key in list(records):
            if records[key].get("_done", float("inf")) < cutoff:
                del records[key]

    async def cleanup():
        while True:
            await asyncio.sleep(30)
            expire()

    @asynccontextmanager
    async def lifespan(app):
        tasks = [asyncio.create_task(process()), asyncio.create_task(cleanup())]
        try:
            yield
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            records.clear()

    app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)

    def authorize(req):
        if local:
            if req.client is None or req.client.host not in LOOPBACK or req.url.hostname not in LOOPBACK:
                raise HTTPException(403, "Local access only.")
        if token and not hmac.compare_digest(req.headers.get("authorization", "").encode(), ("Bearer " + token).encode()):
            raise HTTPException(401, "A valid service token is required.")
        origin = req.headers.get("origin")
        if origin and urlsplit(origin).netloc.lower() != req.headers.get("host", "").lower():
            raise HTTPException(403, "Open this service directly or use the server-side Drape integration.")

    @app.middleware("http")
    async def response_headers(req, call_next):
        res = await call_next(req)
        res.headers["Cache-Control"] = "no-store"
        res.headers["X-Content-Type-Options"] = "nosniff"
        res.headers["Referrer-Policy"] = "no-referrer"
        return res

    @app.get("/")
    async def index():
        return FileResponse(ROOT / "index.html")

    @app.get("/demo/{name}")
    async def demo(name: str):
        if name not in ("person.jpg", "garment.jpg"):
            raise HTTPException(404)
        return FileResponse(ROOT / "demo" / name)

    @app.post("/run", status_code=202)
    async def start(req: Request):
        authorize(req)
        if req.headers.get("content-type", "").split(";", 1)[0].lower() != "application/json":
            raise HTTPException(415, "Use application/json.")
        body = bytearray()
        async for chunk in req.stream():
            if len(body) + len(chunk) > MAX_BODY:
                raise HTTPException(413, "Image request too large.")
            body.extend(chunk)
        expire()
        if sum(1 for row in records.values() if "_done" not in row) >= MAX_JOBS:
            raise HTTPException(429, "The local render queue is full.", headers={"Retry-After": "30"})
        try:
            args = request_images(json.loads(body))
        except (ValueError, TypeError, UnicodeDecodeError) as exc:
            raise HTTPException(422, str(exc)) from exc
        if len(records) >= MAX_RECORDS:
            oldest = min((k for k in records if "_done" in records[k]), key=lambda k: records[k]["_done"])
            del records[oldest]
        job_id = secrets.token_urlsafe(24)
        records[job_id] = {"status": "in_queue", "output": [], "error": None}
        queue.put_nowait((job_id, args))
        return {"id": job_id}

    @app.get("/status/{job_id}")
    async def status(job_id: str, req: Request):
        authorize(req)
        expire()
        rec = records.get(job_id)
        if not rec:
            raise HTTPException(404, "Unknown or expired result.")
        return {key: rec[key] for key in ("status", "output", "error")}

    return app


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7860)
    parser.add_argument("--weights", type=Path, default=ROOT / "weights")
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    parser.add_argument("--steps", type=int, choices=[20, 30, 50], default=50)
    args = parser.parse_args()
    token = os.environ.get("DRAPE_RENDER_TOKEN")
    if (args.host not in LOOPBACK and not token) or (token and len(token) < 32):
        parser.error("Public listeners require DRAPE_RENDER_TOKEN with at least 32 characters.")
    import uvicorn
    rendering = model_renderer(args.weights, args.device, args.steps)
    uvicorn.run(create_app(rendering, token, args.host in LOOPBACK), host=args.host, port=args.port,
                proxy_headers=False, access_log=False)
