# Drape local AI fitting room

Generate a photo from two inputs on a computer you control. Drape runs FASHN VTON v1.5, a pretrained diffusion model conditioned on a person and a garment. It supports tops, bottoms and one-piece outfits. The included example pairs a broad-shouldered studio model with a striped Oxford shirt.

## Install

Use Linux or Windows with Python 3.11 or 3.12, Git and a current NVIDIA driver. A CUDA-capable NVIDIA GPU is recommended. Leave space for PyTorch and about 2.55 GB of model weights.

From this directory, create a virtual environment and activate it in your shell.

```sh
python -m venv .venv
```

On macOS or Linux, run `source .venv/bin/activate`. In Windows PowerShell, run `.venv\Scripts\Activate.ps1`.

The following example installs PyTorch for CUDA 12.6. Select the matching PyTorch wheel for a different driver or platform using [PyTorch’s installation table](https://pytorch.org/get-started/previous-versions/).

```sh
python -m pip install --upgrade pip
python -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu126
python -m pip install -r requirements.txt
python download_weights.py
python server.py
```

Open **http://127.0.0.1:7860** once the server reports that it is listening. Choose **Use the Oxford example**, then **Generate try-on**. You can also select two personal photos and save the generated JPEG. Front-facing, well-lit photos and a clearly visible garment give the model more usable information. Choose **Worn by a person** for a retailer’s on-model photograph. The studio keeps the photo’s aspect ratio when preparing the model input.

Drape runs a 50-step generation by default. For faster experimentation, launch `python server.py --steps 30`. A full CPU-only installation on x86-64 Linux uses the CPU PyTorch wheel, `onnxruntime` in place of `onnxruntime-gpu`, and `python server.py --device cpu`. CPU sampling can take substantially longer and uses more memory. The model redraws the image, including cloth folds, and can alter small details or body features. Use the image as a visual approximation.

## Connect a hosted Drape site

The standalone browser app works on the same computer. To serve the hosted Drape app, run one service process on a GPU host using a private HTTPS origin or an HTTPS reverse proxy. Set a unique random token of 32 or more characters in its environment. Forward only the necessary inference routes and configure upstream rate limits for your own deployment.

```sh
python -c "import secrets; print(secrets.token_urlsafe(40))"
# Set DRAPE_RENDER_TOKEN in the service environment using the generated value.
python server.py --host 0.0.0.0 --port 7860
```

In the Drape site's server-side configuration, set `DRAPE_RENDER_URL` to the service’s HTTPS base URL and `DRAPE_RENDER_TOKEN` to the same token. For the local browser UI on a token-protected service, enter the token in **Service access**.

`POST /run` accepts JSON with `person` and `garment` image data URLs, `category` set to `top`, `bottom` or `dress`, and `garmentPhotoType` set to `flat-lay` or `model`. It returns HTTP 202 and an opaque job ID. Poll `GET /status/{id}` with the same authorization header. A successful response has `status` equal to `completed` and one JPEG data URL in `output`. Jobs awaiting the GPU report `in_queue` and running jobs report `processing`. A failed job reports `failed` with an error object. Queue saturation returns HTTP 429.

The service keeps job data in memory, processes one inference at a time and admits up to three in-flight cases. Completed results expire after 15 minutes or earlier if the bounded result store fills. Images are decoded locally, camera metadata is discarded, and remote image URLs are rejected. Once the package and pinned weights are installed, generation can run offline.

## Weights and credits

The downloader locks and verifies all four large artifacts, including the try-on model, the two DWPose ONNX files and the human parser. The kit downloads pretrained upstream models under their published terms. It includes two original synthetic demonstration photos. See the [FASHN model repository](https://github.com/fashn-AI/fashn-vton-1.5/tree/7c0f10af3f91ad4048fe9729c470a13ef905d25a), [FASHN model card](https://huggingface.co/fashn-ai/fashn-vton-1.5), [DWPose model card](https://huggingface.co/fashn-ai/DWPose), and [human parser license](https://github.com/fashn-AI/fashn-human-parser#license).

The transport smoke test uses a stand-in image function to exercise real uploads, queue handling and authentication without loading the neural network. Run `python -m pip install httpx`, then `python -m unittest test_service`.
