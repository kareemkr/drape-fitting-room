"""Transport smoke test. This injectable test renderer does not run the diffusion model."""
import base64
import time
import unittest
from threading import Event
from fastapi.testclient import TestClient
from server import ROOT, create_app

def photo(name):
    return "data:image/jpeg;base64," + base64.b64encode((ROOT / "demo" / name).read_bytes()).decode("ascii")

def inputs():
    return dict(person=photo("person.jpg"), garment=photo("garment.jpg"), category="top", garmentPhotoType="flat-lay")

class LocalServiceTests(unittest.TestCase):
    def test_local_roundtrip(self):
        seen = []
        def renderer(person, garment, category, kind):
            seen.append((person.mode, garment.mode, category, kind))
            return photo("garment.jpg")
        with TestClient(create_app(renderer, None, True), client=("127.0.0.1", 43120), base_url="http://127.0.0.1:7860") as client:
            self.assertEqual(client.get("/").status_code, 200)
            self.assertEqual(client.get("/demo/person.jpg").headers["content-type"], "image/jpeg")
            self.assertEqual(client.post("/run", json=inputs(), headers={"Origin":"http://other.example"}).status_code, 403)
            self.assertEqual(client.post("/run", json=inputs(), headers={"Host":"other.example"}).status_code, 403)
            job=client.post("/run", json=inputs())
            self.assertEqual(job.status_code, 202)
            route="/status/"+job.json()["id"]
            for _ in range(100):
                result=client.get(route).json()
                if result["status"]=="completed":
                    break
                time.sleep(.01)
            self.assertEqual(result["status"], "completed")
            self.assertTrue(result["output"][0].startswith("data:image/jpeg;base64,"))
            self.assertEqual(seen,[("RGB","RGB","tops","flat-lay")])
            self.assertEqual(client.get("/status/missing").status_code,404)
            self.assertEqual(client.post("/run",json={**inputs(),"garment":"https://example.invalid"}).status_code,422)
            self.assertEqual(client.post("/run",content=b"test",headers={"Content-Type":"text/plain"}).status_code,415)
            self.assertEqual(client.post("/run",json={**inputs(),"category":"shoes"}).status_code,422)

    def test_auth_capacity_and_failure(self):
        token="a"*32
        release=Event()
        def error_renderer(*args):
            release.wait(5)
            raise RuntimeError("Synthetic test failure")
        with TestClient(create_app(error_renderer, token, False)) as client:
            self.assertEqual(client.post("/run",json=inputs()).status_code,401)
            auth={"Authorization":"Bearer "+token}
            routes=[]
            for _ in range(3):
                res=client.post("/run",json=inputs(),headers=auth)
                self.assertEqual(res.status_code,202)
                routes.append("/status/"+res.json()["id"])
            self.assertEqual(client.post("/run",json=inputs(),headers=auth).status_code,429)
            self.assertEqual(client.get(routes[0]).status_code,401)
            release.set()
            for _ in range(100):
                result=client.get(routes[-1],headers=auth).json()
                if result["status"]=="failed":
                    break
                time.sleep(.01)
            self.assertEqual(result["status"],"failed")
            self.assertEqual(result["output"],[])
            self.assertEqual(result["error"]["name"],"InferenceError")
        with self.assertRaises(ValueError):
            create_app(error_renderer,None,False)

if __name__ == "__main__":
    unittest.main()
