"""Fetch the pinned public model artifacts and verify the weight digests."""
import argparse
import hashlib
from pathlib import Path

from huggingface_hub import hf_hub_download, snapshot_download

VTON = ("fashn-ai/fashn-vton-1.5", "7720683168567eb5a2a4c67f15116c6e29c83ded")
DWPOSE = ("fashn-ai/DWPose", "548b5df25b84d9f4aac0611dfa1c2a7a12f15571")
PARSER = ("fashn-ai/fashn-human-parser", "1f80c34dbab321c5730dda5c3fea279fd3e97498")


def verify(path, expected):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        while chunk := source.read(4 * 1024 * 1024):
            digest.update(chunk)
    if digest.hexdigest() != expected:
        raise SystemExit(f"The file {path} did not match its expected SHA-256.")
    print("Verified", path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", type=Path, default=Path(__file__).resolve().parent / "weights")
    root = parser.parse_args().weights
    files = [
        (VTON, "model.safetensors", root, "d6cd38286885bc29fa487ea9383f80ffeb95862e7747c630d42c5d3c05bdd35a"),
        (DWPOSE, "dw-ll_ucoco_384.onnx", root / "dwpose", "724f4ff2439ed61afb86fb8a1951ec39c6220682803b4a8bd4f598cd913b1843"),
        (DWPOSE, "yolox_l.onnx", root / "dwpose", "7860ae79de6c89a3c1eb72ae9a2756c0ccfbe04b7791bb5880afabd97855a411"),
    ]
    for (name, rev), filename, folder, digest in files:
        path = hf_hub_download(repo_id=name, revision=rev, filename=filename, local_dir=folder)
        verify(path, digest)
    parser_dir = root / "parser"
    snapshot_download(repo_id=PARSER[0], revision=PARSER[1], local_dir=parser_dir,
                      allow_patterns=["*.json", "*.safetensors", "*.txt"])
    verify(parser_dir / "model.safetensors", "e43c8c8a9b04f28798f0a4630cf18caa2cdb27a0d454fae43a5716e6f7078244")


if __name__ == "__main__":
    main()
