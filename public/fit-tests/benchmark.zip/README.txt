Drape | 100-garment research benchmark

Open report.html in any browser. The report gives results for both presentation cohorts, all three difficulty levels and the visual review sample.

Files
  case-results.csv           All 100 paired measurements, identifiers, model crop and output digest
  manual-review.csv          Visual comparisons on the stratified spot-check
  source-manifest.csv        Source paths for every selected triplet at the pinned dataset revision
  verify_scores.py           Recomputes each reported group directly from the CSV, with standard Python
  rescore_images.py          Recomputes crop scores on separately held input and output image files

Inspect the numerical summary
  python verify_scores.py

Recompute a case
  Install numpy, Pillow, torch, torchvision and lpips in a Python environment. The LPIPS package fetches its SqueezeNet parameters on first use.
  Provide the same 640 × 640 RGB scene and reference used by the run, the full-frame learned result, and the previous Drape overlay. The case-results.csv coordinates refer to the processed source frame. Use local assets according to their terms.
  python rescore_images.py --case M001 --source person.jpg --reference reference.jpg --output learned.jpg --overlay previous.jpg

Where the files came from
  Source-manifest entries are file paths in the CURVTON-205K sample dataset at revision b0ee6a6066f38658bfef871615f02ad180aeb177. Path strings are relative to its root directory.
  https://huggingface.co/datasets/curvton2/curvton2/tree/b0ee6a6066f38658bfef871615f02ad180aeb177
  Each downloaded RGB image was fit within 640 × 800 with Lanczos resampling, then saved as JPEG with quality 94 and 4:4:4 sampling. All selected scene and reference images were square.
  The dataset describes its images as synthetic and specifies CC BY-NC 4.0 and the FLUX.2 [klein] 9B Non-Commercial License. The separately published DM-VTON model has its own research terms.
  https://github.com/KiseKloset/DM-VTON

CSV columns
  id / cohort / difficulty / garment_type / person_id / garment_id identify the selected example.
  crop_xyxy lists left, top, right and bottom pixel boundaries in the resized source image.
  lpips_crop_source_reference compares the original clothing to the synthetic target.
  lpips_crop_output_reference compares the learned output to that target.
  previous_crop_lpips compares the previous overlay to that target.
  change_to_learned equals overlay distance minus learned distance. Positive values favor the learned output.
  lpips_crop_improvement equals original distance minus learned distance.
  lpips_full_* uses a 256 × 256 version of the full image for secondary checks.
  crop_changed_pixel_fraction gives the crop fraction with a change greater than 12 in any RGB channel.
  native_width and native_height describe the neural model's output patch. output_sha256 identifies the final full-frame JPEG file.
  pose_detected records whether the person pose detector located landmarks. previous_fitter_mode records how the earlier compositor placed that garment.
