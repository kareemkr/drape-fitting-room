"""Recompute crop LPIPS on a selected case with separately held, matching images."""
import argparse
from pathlib import Path
import csv

def main():
    from PIL import Image
    import numpy as np
    import torch
    import lpips
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    for name in ("source", "reference", "output", "overlay"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    records = Path(__file__).resolve().parent / "case-results.csv"
    with records.open(newline="", encoding="utf-8") as f:
        row = next((r for r in csv.DictReader(f) if r["id"] == args.case), None)
    if row is None:
        parser.error("Unknown case ID")
    rect = tuple(map(int, row["crop_xyxy"].split()))
    def prepare(path):
        with Image.open(path) as image:
            crop = image.convert("RGB").crop(rect).resize((192, 256), Image.Resampling.LANCZOS)
            array = np.array(crop, dtype=np.float32) / 127.5 - 1
        return torch.from_numpy(array.transpose(2, 0, 1).copy()).unsqueeze(0)
    metric = lpips.LPIPS(net="squeeze", version="0.1", verbose=False).eval()
    target = prepare(args.reference)
    with torch.inference_mode():
        for label in ("source", "output", "overlay"):
            score = metric(prepare(getattr(args,label)),target).item()
            print(f"{args.case} {label}: {score:.6f}")

if __name__ == "__main__":
    main()
