"""Recompute the fit-report tables using the standard library and case-results.csv."""
import csv
import statistics
from collections import Counter
from pathlib import Path

def summary(rows):
    learned = [float(r["lpips_crop_output_reference"]) for r in rows]
    overlay = [float(r["previous_crop_lpips"]) for r in rows]
    original = [float(r["lpips_crop_source_reference"]) for r in rows]
    return {
        "count": len(rows),
        "closer_than_overlay": sum(a < b for a, b in zip(learned, overlay)),
        "closer_than_source": sum(a < b for a, b in zip(learned, original)),
        "mean_learned": statistics.mean(learned),
        "mean_overlay": statistics.mean(overlay),
        "mean_source": statistics.mean(original),
    }

def groups(rows):
    yield "All", rows
    for key, values in (("cohort", ("male","female")), ("difficulty", ("easy","medium","hard"))):
        for label in values:
            yield label, [r for r in rows if r[key] == label]

if __name__ == "__main__":
    folder = Path(__file__).resolve().parent
    with (folder / "case-results.csv").open(encoding="utf-8", newline="") as f:
        records = list(csv.DictReader(f))
    assert len(records) == len({r["person_id"] for r in records}) == len({r["garment_id"] for r in records}) == 100
    assert Counter(r["cohort"] for r in records) == {"male":50,"female":50}
    assert all(r["status"] == "scored" for r in records)
    print("Group       Cases  Beats overlay  Beats source  Model mean  Overlay mean  Source mean")
    for name, rows in groups(records):
        s = summary(rows)
        print(f"{name:<11} {s['count']:4d}  {s['closer_than_overlay']:13d}  {s['closer_than_source']:12d}  {s['mean_learned']:.4f}      {s['mean_overlay']:.4f}        {s['mean_source']:.4f}")
